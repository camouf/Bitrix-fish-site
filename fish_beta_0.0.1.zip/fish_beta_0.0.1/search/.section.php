<?
$sSectionName = "Поиск по каталогу";
$arDirProperties = Array(
   "description" => "Поиск по каталогу",
   "keywords" => "Поиск по каталогу",
   "title" => "Поиск по каталогу",
   "keywords_inner" => "Поиск по каталогу"
);
?>