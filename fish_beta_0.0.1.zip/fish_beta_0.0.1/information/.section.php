<?
$sSectionName = "Информация";
$arDirProperties = Array(
   "description" => "Информация",
   "keywords" => "Информация",
   "title" => "Информация",
   "keywords_inner" => "Информация"
);
?>