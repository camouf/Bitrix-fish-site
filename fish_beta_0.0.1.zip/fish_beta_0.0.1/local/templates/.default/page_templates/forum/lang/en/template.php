<?
$MESS ['F_THEME_BEIGE'] = "Beige";
$MESS ['F_THEME_BLUE'] = "Blue";
$MESS ['F_THEME_FLUXBB'] = "FluxBB";
$MESS ['F_THEME_GRAY'] = "Gray";
$MESS ['F_THEME_GREEN'] = "Green";
$MESS ['F_THEME_ORANGE'] = "Orange";
$MESS ['F_THEME_RED'] = "Red";
$MESS ['F_THEME_WHITE'] = "White";
$MESS ['forum_template_name'] = "Forum (SEF)";
$MESS ['forum_template_desc'] = "Forums page in SEF mode";
$MESS ['forum_template_settings'] = "Forum Settings";
$MESS ['forum_template_forums'] = "Show Selected Forums Only:";
$MESS ['forum_template_forums_all'] = "(All Forums)";
$MESS ['forum_template_theme'] = "Visual Theme:";
$MESS ['forum_template_vote'] = "Poll Settings";
$MESS ['forum_template_vote_enable'] = "Enable Polls:";
$MESS ['forum_template_vote_channel'] = "Poll Group:";
$MESS ['forum_template_vote_channel_new'] = "Create New Poll Channel";
$MESS ['forum_template_vote_channel_select'] = "Select Existing Poll Channel";
$MESS ['forum_template_vote_groups'] = "User Groups Permitted To Create Polls:";
$MESS ['forum_template_vote_name'] = "Forum's Polls";
?>