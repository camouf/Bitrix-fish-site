<?
$MESS["forum_template_forums_all"] = "(всі форуми)";
$MESS["F_THEME_FLUXBB"] = "FluxBB";
$MESS["F_THEME_BEIGE"] = "Бежевий";
$MESS["F_THEME_WHITE"] = "Білий";
$MESS["forum_template_theme"] = "Візуальна тема:";
$MESS["forum_template_vote_channel_select"] = "Вибрати існуючу групу";
$MESS["F_THEME_BLUE"] = "Блакитний";
$MESS["forum_template_vote_channel"] = "Група опитувань:";
$MESS["forum_template_vote_groups"] = "Групи користувачів, які можуть створювати опитування:";
$MESS["F_THEME_GREEN"] = "Зелений";
$MESS["F_THEME_RED"] = "Червоний";
$MESS["forum_template_vote"] = "Налаштування опитувань на форумі";
$MESS["forum_template_settings"] = "Налаштування форумів";
$MESS["forum_template_vote_name"] = "Опитування для форумів";
$MESS["F_THEME_ORANGE"] = "Помаранчевий";
$MESS["forum_template_forums"] = "Показувати тільки вибрані форуми:";
$MESS["forum_template_vote_enable"] = "Дозволити опитування:";
$MESS["F_THEME_GRAY"] = "Сірий";
$MESS["forum_template_vote_channel_new"] = "Створити нову групу опитувань";
$MESS["forum_template_desc"] = "Сторінка з форумами в режимі ЛЗУ";
$MESS["forum_template_name"] = "Форум (ЛЗУ)";
?>