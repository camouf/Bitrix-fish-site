<?
$MESS["round_nav_back"] = "Назад";
$MESS["round_nav_forward"] = "Вперед";
$MESS["round_nav_pages"] = "Страницы";
$MESS["round_nav_all"] = "Все";
?>