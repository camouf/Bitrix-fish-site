<?
$MESS["round_nav_back"] = "Zurück";
$MESS["round_nav_forward"] = "Weiter";
$MESS["round_nav_pages"] = "Seiten";
$MESS["round_nav_all"] = "Alle";
?>