<?
$MESS ['MFT_NAME'] = "Name";
$MESS ['MFT_EMAIL'] = "Your E-mail";
$MESS ['MFT_MESSAGE'] = "Message";
$MESS ['MFT_CAPTCHA'] = "CAPTCHA";
$MESS ['MFT_CAPTCHA_CODE'] = "Type the letters you see on the picture";
$MESS ['MFT_SUBMIT'] = "Send";
?>