function add2wish(p_id, pp_id, p, name, dpu, th) {
    $.ajax({
        type: "POST",
        url: "/local/ajax/wishlist.php",
        data: "p_id=" + p_id + "&pp_id=" + pp_id + "&p=" + p + "&name=" + name + "&dpu=" + dpu,
        success: function (html) {
            $(th).addClass('in_wishlist');
            $('#wishcount').html(html);
        }
    });
};

function compare_tov(id) {
    var chek = document.getElementById('compareid_' + id);
    if (chek.checked) {
        //Добавить
        var AddedGoodId = id;
        $.get("/local/ajax/list_compare.php",
            {
                action: "ADD_TO_COMPARE_LIST", id: AddedGoodId
            },
            function (data) {
                $("#compare_list_count").html(data);
            }
        );
    }
    else {
        //Удалить
        var AddedGoodId = id;
        $.get("/local/ajax/list_compare.php",
            {
                action: "DELETE_FROM_COMPARE_LIST", id: AddedGoodId
            },
            function (data) {
                $("#compare_list_count").html(data);
            }
        );
    }
}