<?
$MESS["CATALOG_ADD_TO_BASKET"] = "В корзину";
$MESS["CATALOG_MORE_PHOTO"] = "Еще фото";
$MESS["CATALOG_DOWNLOAD"] = "Скачать";
$MESS["CATALOG_BACK"] = "Назад в раздел";
$MESS["CATALOG_BUY"] = "Купить";
$MESS["CATALOG_NOT_AVAILABLE"] = "(нет на складе)";
$MESS["CATALOG_QUANTITY"] = "Количество";
$MESS["CATALOG_QUANTITY_FROM_TO"] = "От #FROM# до #TO#";
$MESS["CATALOG_QUANTITY_FROM"] = "От #FROM#";
$MESS["CATALOG_QUANTITY_TO"] = "До #TO#";
$MESS["CATALOG_PRICE_VAT"] = "с НДС";
$MESS["CATALOG_PRICE_NOVAT"] = "без НДС";
$MESS["CATALOG_VAT"] = "НДС";
$MESS["CATALOG_NO_VAT"] = "не облагается";
$MESS["CATALOG_VAT_INCLUDED"] = "НДС включен в цену";
$MESS["CATALOG_VAT_NOT_INCLUDED"] = "НДС не включен в цену";
$MESS["CT_BCE_QUANTITY"] = "Количество";
$MESS["CT_BCE_CATALOG_ADD"] = "В корзину";
$MESS["CT_BCE_CATALOG_COMPARE"] = "Сравнить";
?>