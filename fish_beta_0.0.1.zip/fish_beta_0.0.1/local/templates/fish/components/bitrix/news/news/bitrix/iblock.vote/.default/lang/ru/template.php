<?
$MESS ['T_IBLOCK_VOTE_BUTTON'] = "Голосовать";
?>