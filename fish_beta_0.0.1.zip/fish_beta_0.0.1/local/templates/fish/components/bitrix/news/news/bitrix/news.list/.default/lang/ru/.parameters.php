<?
$MESS ['T_IBLOCK_DESC_NEWS_DATE'] = "Выводить дату элемента";
$MESS ['T_IBLOCK_DESC_NEWS_NAME'] = "Выводить название элемента";
$MESS ['T_IBLOCK_DESC_NEWS_PICTURE'] = "Выводить изображение для анонса";
$MESS ['T_IBLOCK_DESC_NEWS_TEXT'] = "Выводить текст анонса";
?>