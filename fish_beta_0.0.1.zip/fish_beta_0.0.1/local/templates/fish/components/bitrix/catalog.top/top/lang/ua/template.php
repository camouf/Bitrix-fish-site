<?
$MESS["CT_BCT_ELEMENT_DELETE_CONFIRM"] = "Буде видалена вся інформація, що пов'язана з цим записом. Продовжити?";
$MESS["CATALOG_COMPARE"] = "Порівняти";
$MESS["CT_BCT_TPL_MESS_BTN_ADD_TO_BASKET"] = "До кошику";
$MESS["CT_BCT_TPL_MESS_BTN_BUY"] = "Купити";
$MESS["CT_BCT_TPL_MESS_PRODUCT_NOT_AVAILABLE"] = "Товар наявності";
$MESS["CT_BCT_TPL_MESS_BTN_DETAIL"] = "Детальніше";
$MESS["CT_BCT_TPL_MESS_BTN_SUBSCRIBE"] = "Підписатися";
$MESS["CT_BCT_CATALOG_BTN_MESSAGE_BASKET_REDIRECT"] = "Перейти в кошик";
$MESS["ADD_TO_BASKET_OK"] = "Товар доданий в кошик";
$MESS["CT_BCT_TPL_MESS_PRICE_SIMPLE_MODE_SHORT"] = "від #PRICE#";
$MESS["CT_BCT_CATALOG_TITLE_ERROR"] = "Помилка";
$MESS["CT_BCT_CATALOG_TITLE_BASKET_PROPS"] = "Властивості товару, що додаються до кошику";
$MESS["CT_BCT_CATALOG_BASKET_UNKNOWN_ERROR"] = "Невідома помилка при додаванні товару до кошику";
$MESS["CT_BCT_CATALOG_BTN_MESSAGE_SEND_PROPS"] = "Вибрати";
$MESS["CT_BCT_CATALOG_BTN_MESSAGE_CLOSE"] = "Закрити";
$MESS["CT_BCT_CATALOG_BTN_MESSAGE_CLOSE_POPUP"] = "Продовжити покупки";
$MESS["CT_BCT_CATALOG_MESS_COMPARE_OK"] = "Товар доданий в список порівняння";
$MESS["CT_BCT_CATALOG_MESS_COMPARE_TITLE"] = "Порівняння товарів";
$MESS["CT_BCT_CATALOG_MESS_COMPARE_UNKNOWN_ERROR"] = "При додаванні товару в список порівняння сталася помилка";
$MESS["CT_BCT_CATALOG_BTN_MESSAGE_COMPARE_REDIRECT"] = "Перейти до списку порівняння";
$MESS["CT_BCT_TPL_MESS_BTN_COMPARE"] = "Порівняти";
$MESS["CT_BCT_CATALOG_PRICE_TOTAL_PREFIX"] = "на суму";
$MESS["CT_BCT_CATALOG_SHOW_MAX_QUANTITY"] = "Наявність";
$MESS["CT_BCT_CATALOG_RELATIVE_QUANTITY_MANY"] = "багато";
$MESS["CT_BCT_CATALOG_RELATIVE_QUANTITY_FEW"] = "мало";
?>