<?
$MESS ['CATALOG_COMPARE_BUY'] = "Buy";
$MESS ['CATALOG_NOT_AVAILABLE'] = "(not available from stock)";
$MESS ['CATALOG_ONLY_DIFFERENT'] = "Only different";
$MESS ['CATALOG_ALL_CHARACTERISTICS'] = "All characteristics";
$MESS ['CATALOG_REMOVE_PRODUCTS'] = "Remove products";
$MESS ['CATALOG_REMOVE_FEATURES'] = "Remove features";
$MESS ['CATALOG_REMOVED_FEATURES'] = "Removed features";
$MESS ['CATALOG_ADD_TO_COMPARE_LIST'] = "Add to compare list";
?>