<?
$MESS["subscr_form_title_desc"] = "Виберіть розсилку";
$MESS["subscr_form_email_title"] = "Введіть ваш e-mail";
$MESS["subscr_form_button"] = "Підписатися";
$MESS["subscr_form_response_ERROR"] = "Щось пішло не так";
$MESS["subscr_form_response_NOTE"] = "Вітаємо!";
$MESS["subscr_form_button_sent"] = "ГОТОВО";
?>