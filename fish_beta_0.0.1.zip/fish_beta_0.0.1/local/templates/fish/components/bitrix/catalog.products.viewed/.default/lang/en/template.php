<?
$MESS["CT_CPV_TPL_ELEMENT_DELETE_CONFIRM"] = "This will delete all the information related to this record! Continue?";
$MESS["CT_CPV_TPL_MESS_BTN_BUY"] = "Buy";
$MESS["CT_CPV_TPL_MESS_BTN_ADD_TO_BASKET"] = "Add to cart";
$MESS["CT_CPV_TPL_MESS_PRODUCT_NOT_AVAILABLE"] = "Out of stock";
$MESS["CT_CPV_TPL_MESS_BTN_DETAIL"] = "Details";
$MESS["CT_CPV_TPL_MESS_BTN_SUBSCRIBE"] = "Subscribe";
$MESS["CT_CPV_CATALOG_BTN_MESSAGE_BASKET_REDIRECT"] = "View shopping cart";
$MESS["ADD_TO_BASKET_OK"] = "Added to your shopping cart";
$MESS["CT_CPV_TPL_MESS_BTN_COMPARE"] = "Compare";
$MESS["CT_CPV_CATALOG_TITLE_ERROR"] = "Error";
$MESS["CT_CPV_CATALOG_TITLE_BASKET_PROPS"] = "Item properties to pass to shopping cart";
$MESS["CT_CPV_CATALOG_BASKET_UNKNOWN_ERROR"] = "Unknown error adding an item to shopping cart";
$MESS["CT_CPV_CATALOG_BTN_MESSAGE_SEND_PROPS"] = "Select";
$MESS["CT_CPV_CATALOG_BTN_MESSAGE_CLOSE"] = "Close";
$MESS["CT_CPV_CATALOG_BTN_MESSAGE_CLOSE_POPUP"] = "Continue shopping";
$MESS["CT_CPV_CATALOG_MESS_COMPARE_OK"] = "Product has been added to comparison chart";
$MESS["CT_CPV_CATALOG_MESS_COMPARE_TITLE"] = "Product comparison";
$MESS["CT_CPV_CATALOG_PRICE_TOTAL_PREFIX"] = "total";
$MESS["CT_CPV_CATALOG_MESS_COMPARE_UNKNOWN_ERROR"] = "Error adding the product to comparison chart";
$MESS["CT_CPV_CATALOG_BTN_MESSAGE_COMPARE_REDIRECT"] = "Compare products";
$MESS["CT_CPV_CATALOG_BTN_MESSAGE_LAZY_LOAD_WAITER"] = "Loading";
$MESS["CT_CPV_CATALOG_SHOW_MAX_QUANTITY"] = "Stock";
$MESS["CT_CPV_CATALOG_RELATIVE_QUANTITY_MANY"] = "in stock";
$MESS["CT_CPV_CATALOG_RELATIVE_QUANTITY_FEW"] = "only a few left";
?>