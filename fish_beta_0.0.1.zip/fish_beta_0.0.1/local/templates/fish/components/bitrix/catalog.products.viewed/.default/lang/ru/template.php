<?
$MESS["CT_CPV_TPL_ELEMENT_DELETE_CONFIRM"] = "Будет удалена вся информация, связанная с этой записью. Продолжить?";
$MESS["CT_CPV_TPL_MESS_BTN_BUY"] = "Купить";
$MESS["CT_CPV_TPL_MESS_BTN_ADD_TO_BASKET"] = "В корзину";
$MESS["CT_CPV_TPL_MESS_PRODUCT_NOT_AVAILABLE"] = "Нет в наличии";
$MESS["CT_CPV_TPL_MESS_BTN_DETAIL"] = "Подробнее";
$MESS["CT_CPV_TPL_MESS_BTN_SUBSCRIBE"] = "Подписаться";
$MESS["CT_CPV_CATALOG_BTN_MESSAGE_BASKET_REDIRECT"] = "Перейти в корзину";
$MESS["ADD_TO_BASKET_OK"] = "Товар добавлен в корзину";
$MESS["CT_CPV_TPL_MESS_BTN_COMPARE"] = "Сравнить";
$MESS["CT_CPV_CATALOG_TITLE_ERROR"] = "Ошибка";
$MESS["CT_CPV_CATALOG_TITLE_BASKET_PROPS"] = "Свойства товара, добавляемые в корзину";
$MESS["CT_CPV_CATALOG_BASKET_UNKNOWN_ERROR"] = "Неизвестная ошибка при добавлении товара в корзину";
$MESS["CT_CPV_CATALOG_BTN_MESSAGE_SEND_PROPS"] = "Выбрать";
$MESS["CT_CPV_CATALOG_BTN_MESSAGE_CLOSE"] = "Закрыть";
$MESS["CT_CPV_CATALOG_BTN_MESSAGE_CLOSE_POPUP"] = "Продолжить покупки";
$MESS["CT_CPV_CATALOG_BTN_MESSAGE_BASKET_REDIRECT"] = "Перейти в корзину";
$MESS["CT_CPV_CATALOG_MESS_COMPARE_OK"] = "Товар добавлен в список сравнения";
$MESS["CT_CPV_CATALOG_MESS_COMPARE_TITLE"] = "Сравнение товаров";
$MESS["CT_CPV_CATALOG_PRICE_TOTAL_PREFIX"] = "на сумму";
$MESS["CT_CPV_CATALOG_MESS_COMPARE_UNKNOWN_ERROR"] = "При добавлении товара в список сравнения произошла ошибка";
$MESS["CT_CPV_CATALOG_BTN_MESSAGE_COMPARE_REDIRECT"] = "Перейти в список сравнения";
$MESS["CT_CPV_CATALOG_BTN_MESSAGE_LAZY_LOAD_WAITER"] = "Загрузка";
$MESS["CT_CPV_CATALOG_SHOW_MAX_QUANTITY"] = "Наличие";
$MESS["CT_CPV_CATALOG_RELATIVE_QUANTITY_MANY"] = "много";
$MESS["CT_CPV_CATALOG_RELATIVE_QUANTITY_FEW"] = "мало";
?>