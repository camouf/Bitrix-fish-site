<h5>САЙТ-РЫБА</h5>

<script src="//yastatic.net/es5-shims/0.0.2/es5-shims.min.js"></script>
<script src="//yastatic.net/share2/share.js"></script>
<div class="ya-share2" data-services="collections,vkontakte,facebook,odnoklassniki,moimir,gplus" data-counter=""></div>

<a href="/">
    <img src="<?= SITE_TEMPLATE_PATH; ?>/img/logo.svg" alt="">
</a>

<p>2018 - Все права защищены. Сайт является вымышленным, готовое решение для старта разработки "Рыба"</p>

