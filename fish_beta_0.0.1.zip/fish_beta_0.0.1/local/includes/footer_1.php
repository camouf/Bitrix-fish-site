<h5>ОБРАТНАЯ СВЯЗЬ</h5>

<strong><span>Тел.</span>  +7 (000) 00-00-90</strong>

<p>
г. Любой, ул. Зелёной аллеи, 742 Пристань #548-4
    mail: <a href="mailto:fish@bazarow.ru?subject=Письмо с сайта рыбы">fish@bazarow.ru</a>
</p>