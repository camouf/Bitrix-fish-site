<?
$MESS ['COMP_MAIN_USER_REGISTER_TITLE'] = "Настраиваемая регистрация";
$MESS ['COMP_MAIN_USER_REGISTER_DESCR'] = "Управляемая форма регистрации нового пользователя.";
$MESS ['MAIN_USER_GROUP_NAME'] = "Пользователь";
?>