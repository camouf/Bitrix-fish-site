<?
$MESS["REGISTER_WRONG_CAPTCHA"] = "Wrong CAPTCHA code";
$MESS["REGISTER_FIELD_REQUIRED"] = "Field #FIELD_NAME# is required";
$MESS["REGISTER_DEFAULT_TITLE"] = "New user registration";
$MESS["REGISTER_USER_WITH_EMAIL_EXIST"] = "A user with this e-mail address (#EMAIL#) already exists.";
$MESS["main_register_sess_expired"] = "Your session has expired. Please try to register again.";
$MESS["main_register_decode_err"] = "Password decryption error (#ERRCODE#).";
?>