<?
$MESS ['SEF_MODE_TIP'] = "Enables the SEF mode.";
$MESS ['SHOW_FIELDS_TIP'] = "Select here the additional fields that you want to display in the registration form.";
$MESS ['REQUIRED_FIELDS_TIP'] = "Specify the mandatory fileds here.";
$MESS ['AUTH_TIP'] = "Specifies that a user will be authorised automatically upon successful registration. Otherwise, the authorisation form will be displayed.";
$MESS ['USE_BACKURL_TIP'] = "If a page URL contains the <b>backurl</b> parameter, a user will be redirected to this page upon registration.";
$MESS ['SUCCESS_PAGE_TIP'] = "Specifies a final page to which a user will be redirected upon successful registration.";
$MESS ['SET_TITLE_TIP'] = "Checking this option will set the page title to <b>New User Registration</b>.";
$MESS ['SEF_FOLDER_TIP'] = "Specify here the folder name that will be shown in the address bar when the page is active.";
$MESS ['USER_PROPERTY_TIP'] = "Select additional properties to be displayed in user profile";
?>