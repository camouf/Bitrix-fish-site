<?
$MESS ['COMP_MAIN_USER_REGISTER_TITLE'] = "Customizable registration form";
$MESS ['COMP_MAIN_USER_REGISTER_DESCR'] = "Customizable registration form for a new user.";
$MESS ['MAIN_USER_GROUP_NAME'] = "User";
?>