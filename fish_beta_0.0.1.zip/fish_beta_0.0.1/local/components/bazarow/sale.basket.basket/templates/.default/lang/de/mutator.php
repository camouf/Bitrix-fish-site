<?
$MESS["SBB_DETAIL_PICTURE_NAME"] = "Detailliertes Bild";
$MESS["SBB_PREVIEW_TEXT_NAME"] = "Kurzbeschreibung";
$MESS["SBB_PRICE_TYPE_NAME"] = "Preistyp";
$MESS["SBB_DISCOUNT_NAME"] = "Rabatt";
$MESS["SBB_WEIGHT_NAME"] = "Gewicht";
?>