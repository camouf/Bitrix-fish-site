<?
$MESS["SBB_DETAIL_PICTURE_NAME"] = "Детальное изображение";
$MESS["SBB_PREVIEW_TEXT_NAME"] = "Краткое описание";
$MESS["SBB_PRICE_TYPE_NAME"] = "Тип цены";
$MESS["SBB_DISCOUNT_NAME"] = "Скидка";
$MESS["SBB_WEIGHT_NAME"] = "Вес";
?>