<?
$MESS["SALE_PROPERTIES_RECALCULATE_BASKET"] = "Eigenschaften, die eine Neuberechnung des Warenkorbs beeinflussen";
$MESS["CP_SBB_TPL_THEME_SITE"] = "Farbschema der Website benutzen (für bitrix.eshop)";
$MESS["CP_SBB_TPL_THEME_BLUE"] = "Blau (standardmäßig)";
$MESS["CP_SBB_TPL_THEME_GREEN"] = "Grün";
$MESS["CP_SBB_TPL_THEME_RED"] = "rot";
$MESS["CP_SBB_TPL_THEME_WOOD"] = "Holz";
$MESS["CP_SBB_TPL_THEME_YELLOW"] = "Gelb";
$MESS["CP_SBB_TPL_THEME_BLACK"] = "dunkel";
$MESS["CP_SBB_TPL_TEMPLATE_THEME"] = "Farbschema";
$MESS["CP_SBB_TPL_USE_ENHANCED_ECOMMERCE"] = "E-commerce Daten an Google senden";
$MESS["USE_ENHANCED_ECOMMERCE_TIP"] = "Die Optionen von Google Analytics Enhanced Ecommerce müssen dafür konfiguriert werden";
$MESS["CP_SBB_TPL_DATA_LAYER_NAME"] = "Name des Datencontainers";
$MESS["CP_SBB_TPL_BRAND_PROPERTY"] = "Eigenschaft der Handelsmarken";
?>