<?
$MESS["SALE_PROPERTIES_RECALCULATE_BASKET"] = "Свойства, влияющие на пересчет корзины";
$MESS["CP_SBB_TPL_THEME_SITE"] = "Брать тему из настроек сайта (для решения bitrix.eshop)";
$MESS["CP_SBB_TPL_THEME_BLUE"] = "синяя (тема по умолчанию)";
$MESS["CP_SBB_TPL_THEME_GREEN"] = "зеленая";
$MESS["CP_SBB_TPL_THEME_RED"] = "красная";
$MESS["CP_SBB_TPL_THEME_WOOD"] = "дерево";
$MESS["CP_SBB_TPL_THEME_YELLOW"] = "желтая";
$MESS["CP_SBB_TPL_THEME_BLACK"] = "темная";
$MESS["CP_SBB_TPL_TEMPLATE_THEME"] = "Цветовая тема";
$MESS["CP_SBB_TPL_USE_ENHANCED_ECOMMERCE"] = "Отправлять данные электронной торговли в Google и Яндекс";
$MESS["USE_ENHANCED_ECOMMERCE_TIP"] = "Требуется дополнительная настройка в Google Analytics Enhanced 
Ecommerce и/или Яндекс.Метрике";
$MESS["CP_SBB_TPL_DATA_LAYER_NAME"] = "Имя контейнера данных";
$MESS["CP_SBB_TPL_BRAND_PROPERTY"] = "Свойство брендов";
?>