<?
$MESS["SALE_PROPERTIES_RECALCULATE_BASKET"] = "Властивості, що впливають на перерахунок кошика";
$MESS["CP_SBB_TPL_THEME_SITE"] = "Брати тему з налаштувань сайту (для вирішення bitrix.eshop)";
$MESS["CP_SBB_TPL_THEME_BLUE"] = "синя (тема за замовчуванням)";
$MESS["CP_SBB_TPL_THEME_GREEN"] = "зелена";
$MESS["CP_SBB_TPL_THEME_RED"] = "червона";
$MESS["CP_SBB_TPL_THEME_WOOD"] = "дерево";
$MESS["CP_SBB_TPL_THEME_YELLOW"] = "жовта";
$MESS["CP_SBB_TPL_THEME_BLACK"] = "темна";
$MESS["CP_SBB_TPL_TEMPLATE_THEME"] = "Колірна тема";
$MESS["CP_SBB_TPL_USE_ENHANCED_ECOMMERCE"] = "Надсилати дані електронної торгівлі в Google і Яндекс";
$MESS["USE_ENHANCED_ECOMMERCE_TIP"] = "Потрібне додаткове налаштування в Google Analytics Enhanced 
Ecommerce та/або Яндекс.Метриці";
$MESS["CP_SBB_TPL_DATA_LAYER_NAME"] = "Ім'я контейнера даних";
$MESS["CP_SBB_TPL_BRAND_PROPERTY"] = "Властивість брендів";
?>