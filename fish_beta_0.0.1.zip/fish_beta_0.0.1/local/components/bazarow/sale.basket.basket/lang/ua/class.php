<?
$MESS["SALE_EMPTY_BASKET"] = "Ваш кошик порожній";
$MESS["SBB_PRODUCT_NOT_AVAILABLE"] = "Товар #PRODUCT# не доступний для замовлення";
$MESS["SBB_PRODUCT_NOT_ENOUGH_QUANTITY"] = "Для оформлення замовлення недостатньо товару \"#PRODUCT#\" в кількість #NUMBER#";
$MESS["SOA_TEMPL_ORDER_PS_ERROR"] = "Помилка обраного способу оплати. Зверніться до Адміністрації сайту, або виберіть інший спосіб оплати.";
$MESS["SBB_TITLE"] = "Мій кошик";
?>