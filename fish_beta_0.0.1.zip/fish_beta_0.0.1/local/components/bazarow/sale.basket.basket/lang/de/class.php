<?
$MESS["SALE_EMPTY_BASKET"] = "Ihr Warenkorb ist leer";
$MESS["SBB_PRODUCT_NOT_AVAILABLE"] = "#PRODUCT# ist nicht vorrätig";
$MESS["SBB_PRODUCT_NOT_ENOUGH_QUANTITY"] = "Der aktuelle Vorrat von \"#PRODUCT#\" ist unzureichend (#NUMBER# ist erforderlich)";
$MESS["SOA_TEMPL_ORDER_PS_ERROR"] = "Bei der ausgewählten Zahlungsoption ist ein Fehler aufgetreten. Kontaktieren Sie bitte Ihren Website-Administrator oder wählen Sie eine andere Zahlungsoption aus.";
$MESS["SBB_TITLE"] = "Mein Warenkorb";
$MESS["SALE_MODULE_NOT_INSTALL"] = "Das Modul Onlineshop ist nicht installiert.";
$MESS["SBB_PRODUCT_QUANTITY_CHANGED"] = "Produktmenge wurde geändert";
$MESS["SBB_BASKET_ITEM_WRONG_AVAILABLE_QUANTITY"] = "Entschuldigung, die Produktmenge, die Sie ausgewählt haben, ist momentan nicht verfügbar.<br>Vorheriger korrekter Wert wurde gesetzt.";
?>