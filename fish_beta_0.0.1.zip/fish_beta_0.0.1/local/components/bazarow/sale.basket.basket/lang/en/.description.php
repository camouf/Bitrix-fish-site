<?
$MESS ['SBB_DEFAULT_TEMPLATE_NAME'] = "Basket";
$MESS ['SBB_DEFAULT_TEMPLATE_DESCRIPTION'] = "Displays basket for the current user";
$MESS ['SBB_NAME'] = "Basket";
?>