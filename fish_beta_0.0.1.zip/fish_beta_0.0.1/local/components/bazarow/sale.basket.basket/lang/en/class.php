<?
$MESS["SALE_EMPTY_BASKET"] = "Your shopping cart is empty";
$MESS["SBB_PRODUCT_NOT_AVAILABLE"] = "#PRODUCT# is out of stock";
$MESS["SBB_PRODUCT_NOT_ENOUGH_QUANTITY"] = "The current stock of \"#PRODUCT#\" is insufficient (#NUMBER# is required)";
$MESS["SOA_TEMPL_ORDER_PS_ERROR"] = "The selected payment method failed. Please contact the site administrator or select another method.";
$MESS["SBB_TITLE"] = "My shopping cart";
$MESS["SALE_MODULE_NOT_INSTALL"] = "The e-Store module is not installed.";
$MESS["SBB_PRODUCT_QUANTITY_CHANGED"] = "Product quantity was changed";
$MESS["SBB_BASKET_ITEM_WRONG_AVAILABLE_QUANTITY"] = "Sorry, the product quantity you selected is currently unavailable.<br>Using the previous correct value.";
?>