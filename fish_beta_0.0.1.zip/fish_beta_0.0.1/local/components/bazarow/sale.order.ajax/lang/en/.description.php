<?
$MESS["SOF_DEFAULT_TEMPLATE_DESCRIPTION"] = "Single-step ordering procedure without page reload";
$MESS["SOF_NAME"] = "Ordering Procedure";
$MESS["SOF_DEFAULT_TEMPLATE_NAME1"] = "Checkout";