<?
$MESS["SOF_DEFAULT_TEMPLATE_NAME"] = "Однокрокове оформлення замовлення";
$MESS["SOF_DEFAULT_TEMPLATE_DESCRIPTION"] = "Оформлення замовлення на одній сторінці без перезавантаження";
$MESS["SOF_NAME"] = "Процедура оформлення замовлення";
$MESS["SOF_DEFAULT_TEMPLATE_NAME1"] = "Оформлення замовлення";
?>