<?
$MESS["MAP_PHONE"] = "Телефон";
$MESS["MAP_ADRES"] = "Адреса";
$MESS["MAP_WORK"] = "Режим роботи";
$MESS["MAP_STORE"] = "Склад";
$MESS["MAP_EMAIL"] = "Електронна пошта";
$MESS["MAP_DESC"] = "Опис";
?>