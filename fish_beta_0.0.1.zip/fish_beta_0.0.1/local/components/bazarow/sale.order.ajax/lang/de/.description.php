<?
$MESS["SOF_NAME"] = "Bestellprozess";
$MESS["SOF_DEFAULT_TEMPLATE_DESCRIPTION"] = "Bestellprozess in einem Schritt";
$MESS["SOF_DEFAULT_TEMPLATE_NAME1"] = "Checkout";