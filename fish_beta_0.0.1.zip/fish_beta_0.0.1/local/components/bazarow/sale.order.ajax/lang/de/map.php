<?
$MESS["MAP_PHONE"] = "Telefon";
$MESS["MAP_ADRES"] = "Adresse";
$MESS["MAP_WORK"] = "Öffnungszeiten";
$MESS["MAP_STORE"] = "Lager";
$MESS["MAP_EMAIL"] = "E-Mail";
$MESS["MAP_DESC"] = "Beschreibung";
?>