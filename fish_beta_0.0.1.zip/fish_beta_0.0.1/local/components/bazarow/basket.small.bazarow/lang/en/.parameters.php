<?
$MESS["SBBS_PATH_TO_BASKET"] = "Basket page";
$MESS["SBBS_PATH_TO_ORDER"] = "Order page";
$MESS["SBBS_SHOW_DELAY"] = "Show reserved goods";
$MESS["SBBS_SHOW_NOTAVAIL"] = "Show goods not currently in inventory";
$MESS["SBBS_SHOW_SUBSCRIBE"] = "Show goods to which the user is subscribed ";
?>