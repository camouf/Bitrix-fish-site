<?
$MESS["TSBS_READY"] = "Items in your Shopping Cart:";
$MESS["TSBS_PRICE"] = "Price:";
$MESS["TSBS_QUANTITY"] = "Quantity:";
$MESS["TSBS_2BASKET"] = "Change Quantity";
$MESS["TSBS_2ORDER"] = "Order";
$MESS["TSBS_DELAY"] = "Hold over:";
$MESS["TSBS_UNAVAIL"] = "Currently unavailable:";
$MESS["TSBS_SUBSCRIBE"] = "Subscription:";
?>