<?
$MESS ['T_IBLOCK_DESC_CATALOG'] = "Catalog";
$MESS ['IBLOCK_COMPARE_LIST_TEMPLATE_NAME'] = "List of the compared catalog elements";
$MESS ['IBLOCK_COMPARE_LIST_TEMPLATE_DESCRIPTION'] = "Displays the middle-size comparisom table of the catalog elements ";
?>