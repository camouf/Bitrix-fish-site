<?
$MESS ['IBLOCK_TYPE_TIP'] = "Select one of existing information block types in the list and click <b>OK</b>. This will load information blocks of the selected type.";
$MESS ['IBLOCK_ID_TIP'] = "Select one of information blocks of the chosen type. If you select <b>(other)-&gt;</b>, specify the information block ID in the field beside.";
$MESS ['DETAIL_URL_TIP'] = "Specify here the path to an information block element details page.";
$MESS ['COMPARE_URL_TIP'] = "Specify here the path to the comparison page for elements of a current information block.";
$MESS ['NAME_TIP'] = "The name of a variable to pass the list of elements to compare. The default value is <b>CATALOG_COMPARE_LIST</b>.";
$MESS ['AJAX_MODE_TIP'] = "Enables AJAX in the component.";
$MESS ['AJAX_OPTION_SHADOW_TIP'] = "Specifies to shade modifiable area on AJAX transition.";
$MESS ['AJAX_OPTION_JUMP_TIP'] = "Specifies to scroll to component when AJAX transition completes.";
$MESS ['AJAX_OPTION_STYLE_TIP'] = "Specifies to download and process CSS styles of component on AJAX transition.";
$MESS ['AJAX_OPTION_HISTORY_TIP'] = "Allows \"Back\" and \"Forward\" browser buttons for AJAX transitions.";
?>