<?
$MESS["IBLOCK_DETAIL_URL"] = "URL of the page with the detail contents";
$MESS["IBLOCK_TYPE"] = "Info-block type";
$MESS["IBLOCK_IBLOCK"] = "Info-block";
$MESS["IBLOCK_COMPARE_URL"] = "URL of the comparison table page ";
$MESS["IBLOCK_COMPARE_NAME"] = "Unique name for the comparison list";
?>