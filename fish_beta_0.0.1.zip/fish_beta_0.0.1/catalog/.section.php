<?
$sSectionName = "Каталог";
?>