<?
$arDirProperties = Array(
   "save_kernel" => "Y"
);
?>