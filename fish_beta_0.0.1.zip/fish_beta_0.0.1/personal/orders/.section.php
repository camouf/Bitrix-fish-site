<?
$sSectionName = "Мои заказы";
$arDirProperties = Array(
   "description" => "Мои заказы",
   "keywords" => "Мои заказы",
   "title" => "Мои заказы",
   "keywords_inner" => "Мои заказы"
);
?>